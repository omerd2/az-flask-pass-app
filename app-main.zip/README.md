# Deploy a Python (Flask) web app - Sample Application


If you need an Azure account, you can [create one for free](https://azure.microsoft.com/en-us/free/).
